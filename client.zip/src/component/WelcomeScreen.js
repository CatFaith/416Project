export default function WelcomeScreen() {
    return (
        <div id="Welcome-screen">
            Welcome to Sheet to App<br />
        </div>
    )
}