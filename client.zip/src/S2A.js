// APP Class
import './index.css';
import { React } from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import {
    Drive,
    Toolbar,
    detailView,
    EditPanel,
    tableView
} from './components'

/*
const App = () => {
    return (
        <BrowserRouter>
            <AuthContextProvider>
                <GlobalStoreContextProvider>              
                    <AppBanner />
                    <Switch>
                        <Route path="/" exact component={HomeWrapper} />
                        <Route path="/register/" exact component={RegisterScreen} />
                        <Route path="/top5list/:id" exact component={WorkspaceScreen} />
                        <Route path="/signin/" exact component={SignInSide}/>
                    </Switch>
                    <Statusbar />
                </GlobalStoreContextProvider>
            </AuthContextProvider>
        </BrowserRouter>
    )
}

export default App
*/
